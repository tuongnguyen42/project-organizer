package application;

import java.beans.XMLDecoder;
import java.beans.XMLEncoder;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Optional;

import javafx.application.Platform;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.ScrollPane;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.stage.FileChooser;
import javafx.stage.Stage;

public class MainScreen implements ModelListener{

	private Stage mainScreen;
	private BorderPane boardLayout;
	private TaskBoardModel taskBoard;
	private ProjectView currentPV;
	private Button newPB;
	private Button editB;
	private Button saveB;
	private Button loadB;
	private Button logoutB;
	private ChoiceBox<String> chooseProj;
	
	public MainScreen(Stage stage) throws IOException{

		mainScreen = stage;
		boardLayout = new BorderPane();
		taskBoard = new TaskBoardModel();
		
		taskBoard.attach(this);
		
		createMainScreen();
		
		mainScreen.setScene(new Scene(boardLayout));
		mainScreen.show();
		
		mainScreen.setOnCloseRequest(e -> {
			if (Main.DIRTY) {
				savePopup();
				e.consume();
			} 
			else {
				Platform.exit();
				System.exit(0);
			}
				
			
		});
		
	}
	
	public void loadFile (File file) throws IOException {
		XMLDecoder decoder = new XMLDecoder(new BufferedInputStream (new FileInputStream(file.getPath())));
		this.taskBoard = (TaskBoardModel) decoder.readObject();
		decoder.close();
		taskBoard.attach(this);
		currentPV = new ProjectView(this.mainScreen, this.taskBoard, this.taskBoard.getCurrentPM());
		currentPV.update();
		
		this.mainScreen.show();
	}

	private void savePopup() {
		Alert saveAlert = new Alert(Alert.AlertType.CONFIRMATION);
		saveAlert.setTitle("Save");
		saveAlert.setHeaderText(null);
        saveAlert.setContentText("This project has been changed, click \"save\" to save these progress.");
        ButtonType saveTp = new ButtonType("SAVE");
        ButtonType exitTp = new ButtonType("EXIT");
        ButtonType okTp = new ButtonType("OK");
        saveAlert.getButtonTypes().setAll(saveTp,exitTp, okTp);
        Optional<ButtonType> op = saveAlert.showAndWait();
        if(op.get() == saveTp)
            saveB.fire();
        else if(op.get() == exitTp) {
            Platform.exit();
            System.exit(0);
        }
	}

	private void save(File file) throws FileNotFoundException {
        XMLEncoder encoder = new XMLEncoder(new BufferedOutputStream( new FileOutputStream(file)));
        encoder.writeObject(taskBoard);
        encoder.close();
        Main.DIRTY = false;
	}

	private void createMainScreen() throws IOException {

		this.newPB = new Button("New Project");
		this.editB = new Button("Edit");
		this.saveB = new Button("Save");
		this.logoutB = new Button("Logout");
		this.loadB = new Button("Load...");
		chooseProj = new ChoiceBox();
		
		HBox buttonBox = new HBox(12);
		buttonBox.getChildren().addAll(newPB, editB, saveB, loadB, logoutB);
		buttonBox.setPadding(new Insets(12));
		
		buttonBox.getChildren().add(chooseProj);
		
		boardLayout.setTop(buttonBox);
		
		
		newPB.setOnAction(e -> {
			currentPV = new ProjectView(mainScreen, taskBoard, new ProjectModel());
			currentPV.createProj();
			taskBoard.setCurrentPM(currentPV.getProj());
			
		});
		
		editB.setOnAction(e->{
			currentPV.editProject();
		});
		
		saveB.setOnAction(e->{
			FileChooser chooser = new FileChooser();
			FileChooser.ExtensionFilter extensionFilter = new FileChooser.ExtensionFilter("XML file (*.xml)", "*.xml");
			chooser.getExtensionFilters().add(extensionFilter);
			
			File file = chooser.showSaveDialog(this.mainScreen);
			
			if(file != null)
				try {
					save(file);
				} catch (FileNotFoundException e1) {

					e1.printStackTrace();
				}

		});
		
		
		loadB.setOnAction(e->{
			if (Main.DIRTY) {
				if(needSave()) return;
			}
			
			Main.DIRTY = false;
			
			try{
                FileChooser chooser = new FileChooser();
                chooser.setTitle("Open TaskBoard");
                FileChooser.ExtensionFilter extensionFilter =
                        new FileChooser.ExtensionFilter("XML file (*.xml)", "*.xml");
                chooser.getExtensionFilters().add(extensionFilter);

                File file = chooser.showOpenDialog(this.mainScreen);
                if(file != null)
                    loadFile(file);
            }catch (IOException ex) {
                ex.printStackTrace();
            }
			
		});
		
		
		logoutB.setOnAction(e->{
			if(Main.DIRTY) {
				if(needSave()) return;
			}
			
			try {
				Main.DIRTY = false;
				Main.openLogin();
				this.mainScreen.close();
			}catch (Exception ex) {
				ex.printStackTrace();
			}
		});
		
		chooseProj.setOnAction(e->{
			int p = 0;
			
			for(int i = 0; i< taskBoard.getProjectList().size(); i++) {
				if (taskBoard.getProjectList().get(i).getName().equals(chooseProj.getValue()))
					p = i;
			}
			taskBoard.setCurrentPM(taskBoard.getProjectList().get(p));
			currentPV = new ProjectView(mainScreen, taskBoard, taskBoard.getProjectList().get(p));
			currentPV.update();
		});
	}
	
	public void update() {
		Main.DIRTY = true;
		
		ScrollPane sp = new ScrollPane();
		
		sp.setContent(currentPV.getProjectLayout());
		boardLayout.setCenter(sp);
		
		sp.setVbarPolicy(ScrollPane.ScrollBarPolicy.NEVER);
	    sp.setHbarPolicy(ScrollPane.ScrollBarPolicy.NEVER);
	    
	    chooseProj.getItems().setAll(taskBoard.getProjectNames());
	    
	    
	    
		
	}

	private boolean needSave() {
	       Alert saveAlert = new Alert(Alert.AlertType.CONFIRMATION);
	        saveAlert.setTitle("Save Warning");
	        saveAlert.setHeaderText(null);
	        saveAlert.setContentText("To save latest changes, click \"save\" to save these progress.");
	            ButtonType saveTp = new ButtonType("SAVE");
	            ButtonType continueTp = new ButtonType("CONTINUE");
	            saveAlert.getButtonTypes().setAll(saveTp, continueTp);
	            Optional<ButtonType> op = saveAlert.showAndWait();
	            if(op.get() == saveTp) {
	                saveB.fire();
	                return true;
	            }
	            return false;
	}
	
	
	


}
