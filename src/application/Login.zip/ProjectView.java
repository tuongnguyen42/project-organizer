package application;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;
import java.util.TreeSet;
import java.util.stream.IntStream;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.effect.*;
import javafx.scene.input.MouseEvent;
import javafx.scene.input.TransferMode;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontPosture;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.stage.Modality;
import javafx.stage.Stage;

public class ProjectView implements ModelListener{
	
	private ProjectModel project;
	private TaskBoardModel taskBoard;
	private HBox projectLayout;
	private Stage projectStage;



	public ProjectView(Stage stage, TaskBoardModel taskBoard, ProjectModel projectModel) {
		this.projectStage = stage;
		this.project = projectModel;
		projectLayout = new HBox(12);
		project.attach(this);
	}

	public void update() {
		this.projectLayout = showProject();
		taskBoard.updateAll();
	}

	private HBox showProject() {
		HBox columnHolder = new HBox(12);
		ArrayList<VBox> columnsList = new ArrayList<>();
		ArrayList<TaskView> taskViews = new ArrayList<>();
		
		for(TaskModel each :project.getTasks()) {
			taskViews.add(new TaskView(this.projectStage, project, each));
		}
		
		  for (String each : project.getColumns()) {
	            // each column is a VBox
	            VBox column = new VBox(12);
	            column.setId(each); // id of column is column name, used for drag and drop
	            Button addTaskBtn = new Button("+");
	     
	            addTaskBtn.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {
	                addTaskBtn.setStyle("-fx-background-color: #FFFFFF");
	                addTaskBtn.setTextFill(Color.BLACK);
	            });
	            addTaskBtn.setOnAction(e -> {
	                TaskModel taskModel = new TaskModel();
	                // create a task under the add Btn of that column
	                taskModel.setStatus(addTaskBtn.getId());
	                TaskView taskView = new TaskView(this.projectStage, taskBoard.getCurrentPM(), taskModel);
	                taskView.createTask();
	            });
	            column.setPadding(new Insets(12));
	            column.setId(each);// each VBox has an ID same as column name
	            Text cName = new Text(each);
	     
	            column.getChildren().addAll(cName, addTaskBtn);
	            columnsList.add(column);
	        }
	        for (TaskView each : taskViews) {
	            for (VBox column : columnsList) {
	                if (column.getId().equals(each.getTask().getStatus())) {
	                    column.getChildren().add(each.getTaskForm());
	                }
	            }
	        }
	        //UI
	        for(VBox each : columnsList) {
	            //UI part
	            each.setMinWidth(180);
	        }

	        for(VBox each : columnsList) {
	            columnHolder.getChildren().addAll(each);
	        }
	        // this delete area will be used in drag and drop function
	        VBox deleteArea = new VBox(20);
	        deleteArea.setId("delete");
	        deleteArea.setMinWidth(180);
	        Label deleteLb = new Label("X");
	
	        columnHolder.getChildren().add(deleteArea);

	        return columnHolder;

	}


	public ProjectModel getProj() {
		return project;
	}
	
	private boolean deleteAlert() {
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Task Delete Warning");
        alert.setHeaderText(null);
        alert.setContentText("Delete this Task?");
        ButtonType deleteTp = new ButtonType("DELETE");
        ButtonType cancelTp = new ButtonType("CANCEL");
        alert.getButtonTypes().setAll(deleteTp, cancelTp);
        Optional<ButtonType> op = alert.showAndWait();
        if(op.get() == deleteTp) {
            return true;
        }
        return false;
    }
	
	public HBox getProjectLayout () {
		return projectLayout;
	}
	
	public void createProj() {
		Stage s = new Stage();
        s.initModality(Modality.APPLICATION_MODAL);
        s.setTitle("New Project");
        
        GridPane layout = new GridPane();
        layout.setAlignment(Pos.CENTER);
        VBox wrapper = new VBox();
        VBox projectLayout = new VBox(8);
        projectLayout.setAlignment(Pos.CENTER);
        VBox namePane = new VBox(8);
        Label name = new Label("Project Name");
        TextField nameField =  new TextField();
        namePane.getChildren().addAll(name, nameField);
        namePane.setPadding(new Insets(8));
        
        
        HBox addRemove = new HBox(100);
        addRemove.setAlignment(Pos.CENTER);
        Button addB = new Button("+");
        Button removeB = new Button("-");
        addB.setMinSize(50, 50);
        removeB.setMinSize(50, 50);
        
        
        VBox addColumnPane = new VBox(8);
        ArrayList<TextField> columnNameFields = new ArrayList<>();
        addColumnPane.setPadding(new Insets(8));
        
        HBox bPanel = new HBox(100);
        bPanel.setAlignment(Pos.CENTER);
        Button createB = new Button("Create");
        Button cancelB = new Button("Cancel");
        
        bPanel.getChildren().addAll(createB, cancelB);
        
        addRemove.getChildren().addAll(addB, removeB);
        
        Text errorText = new Text("");
        
        errorText.setFill(Color.RED);
        
        projectLayout.getChildren().addAll(namePane, addRemove,addColumnPane, bPanel, errorText);
        
        wrapper.getChildren().add(projectLayout);
        
        addB.setOnAction(e -> {
            if(addColumnPane.getChildren().size() < 5) {
                removeB.setDisable(false);
                VBox newColumn = new VBox(8);
                Label tempText = new Label("Column name:");
                TextField tempField = new TextField();
                columnNameFields.add(tempField);
                newColumn.getChildren().addAll(tempText, tempField);
                addColumnPane.getChildren().add(newColumn);
                if(addColumnPane.getChildren().size() == 5) addB.setDisable(true);
            }
        });
        
        IntStream.range(0, 3).forEach(i -> addB.fire());
        
        removeB.setOnAction(e -> {
            if(addColumnPane.getChildren().size() > 1) {
                addB.setDisable(false);
                columnNameFields.remove(columnNameFields.size()-1);
                addColumnPane.getChildren().remove(addColumnPane.getChildren().size()-1);
                if(addColumnPane.getChildren().size() == 1) removeB.setDisable(true);
            }
        });
        
        
        
        createB.setOnAction(e -> {
            ArrayList<String> seen = new ArrayList<>();
            for(TextField each : columnNameFields) {
                if(each.getText().equals("")) {
                    errorText.setText("Empty Name Fields");
                    return;
                }
                else if(seen.contains(each.getText())) {
                    errorText.setText("Duplicate Column Names");
                    return;
                }
                seen.add(each.getText());
            }
//            if(nameField.getText().equals("")) {errorText.setText("Empty Project Name"); return; }
//            else if(taskBoard.getProjectNames().contains(nameField.getText())) {errorText.setText("Project already exist."); return;}
            project.setName(nameField.getText());// set name
            project.setColumns(new ArrayList<String>());
            for(TextField each : columnNameFields) {
                project.addColumn(each.getText());
            }

            taskBoard.addProject(project);// start add it in
            taskBoard.setCurrentPM(project);// set it to current running project

            projectStage.close();
        });
        
        
        cancelB.setOnAction(e -> {
            projectStage.close();
        });
        
        layout.add(wrapper, 1, 0);
        
        Scene cpScene = new Scene(layout);
        projectStage.setScene(cpScene);
        projectStage.show();
       
	}

	public void editProject() {
		Stage stage = new Stage();
		stage.initModality(Modality.APPLICATION_MODAL);
		stage.setTitle(project.getName());
		
		GridPane layout = new GridPane();
		layout.setAlignment(Pos.CENTER);
		
		VBox wrapper = new VBox();
        wrapper.setAlignment(Pos.CENTER);
        wrapper.setPadding(new Insets(20));
        wrapper.setMinWidth(400);
        
        VBox projectLayout = new VBox(8);
        projectLayout.setAlignment(Pos.CENTER);
        
        
        VBox namePane = new VBox(8);
        Label nameText = new Label("Project Name:");
        TextField nameField = new TextField();
        nameField.setText(project.getName());
        namePane.getChildren().addAll(nameText, nameField);
        namePane.setPadding(new Insets(8));
        
        HBox addRemove = new HBox(100);
        addRemove.setAlignment(Pos.CENTER);
        Button addB = new Button("+");
        Button removeB = new Button("-");
        addB.setMinSize(50, 50);
        removeB.setMinSize(50, 50);
        
        
        VBox addColumnPane = new VBox(8);
        ArrayList<TextField> columnNameFields = new ArrayList<>();
        addColumnPane.setPadding(new Insets(8));
        
        HBox bPanel = new HBox(100);
        bPanel.setAlignment(Pos.CENTER);
        Button doneB = new Button("Done");
        Button cancelB = new Button("Cancel");
        
        bPanel.getChildren().addAll(doneB, cancelB);
        
        addRemove.getChildren().addAll(addB, removeB);
        
        Text errorText = new Text("");
        
        errorText.setFill(Color.RED);
        
        projectLayout.getChildren().addAll(namePane, addRemove,addColumnPane, bPanel, errorText);
        
        wrapper.getChildren().add(projectLayout);
        
        
        addB.setOnAction(e -> {
            if(addColumnPane.getChildren().size() < 5) {
                removeB.setDisable(false);
                VBox newColumn = new VBox(8);
                Label tempText = new Label("Column name:");
                TextField tempField = new TextField();
                columnNameFields.add(tempField);
                newColumn.getChildren().addAll(tempText, tempField);
                addColumnPane.getChildren().add(newColumn);
                if(addColumnPane.getChildren().size() == 5) addB.setDisable(true);
            }
        });
        
        
        removeB.setOnAction(e -> {
            if(addColumnPane.getChildren().size() > 1) {
                addB.setDisable(false);
                columnNameFields.remove(columnNameFields.size()-1);
                addColumnPane.getChildren().remove(addColumnPane.getChildren().size()-1);
                if(addColumnPane.getChildren().size() == 1) removeB.setDisable(true);
            }
        });
        
        doneB.setOnAction(e ->{
        	ArrayList<String> seen = new ArrayList<>();
        	for(TextField each : columnNameFields) {
        		if(each.getText().equals("")) {
        			errorText.setText("Empty Column Name");
        			return;
        		}
        		else if (seen.contains(each.getText())) {
        			errorText.setText("Duplicate Column Names");
        			return;
        		}
        		seen.add(each.getText());
        	}
        	 project.setName(nameField.getText());
             ArrayList<String> preColumnList = project.getColumns();
             ArrayList<String> newColumnList = new ArrayList<>();
             
             for(TextField each : columnNameFields) {
                 newColumnList.add(each.getText());
             }
             
             Map<String, String> oldToNew = new HashMap<>();
             for(int i = 0; i < preColumnList.size(); i++) {
                 if(i < newColumnList.size())
                     oldToNew.put(preColumnList.get(i), newColumnList.get(i));
                 else oldToNew.put(preColumnList.get(i), null);
             }
             
             TreeSet<TaskModel> temp = new TreeSet<>();
             for(TaskModel each : project.getTasks()) {
                 temp.add(new TaskModel(each));
             }
             for(TaskModel each : temp) {
                 // set the new status
                 for(String oldColumnName : oldToNew.keySet()) {
                     // original column has been deleted
                     if(each.getStatus() == null) {
                         continue;
                     }
                     else if(each.getStatus().equals(oldColumnName)) {
                         each.setStatus(oldToNew.get(oldColumnName));
                     }
                 }
             }
             TreeSet<TaskModel> temp1 = new TreeSet<>();
             for(TaskModel each : temp) {
                 temp1.add(new TaskModel(each));
             }
             project.setTaskSet(temp);
             // if task status is null remove it from task set
             for(TaskModel each : temp1) {
                 if(each.getStatus() == null)
                     project.removeTask(each);
             }
             project.setColumns(newColumnList);
             projectStage.close();
        });
        
        Scene cpScene = new Scene(layout);
        projectStage.setScene(cpScene);
        projectStage.show();
        
        
        
        
	}
	
	


}
