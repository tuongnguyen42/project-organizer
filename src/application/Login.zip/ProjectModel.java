package application;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.TreeSet;

public class ProjectModel extends TaskBoardModel {
	private String projName;
	private ArrayList<String> columnNames;
	private TreeSet<TaskModel> tasks;
	ArrayList<ModelListener> listeners = new ArrayList<>();
	
	
	public ProjectModel() {
		this.projName = "Project 1";
		this.columnNames = new ArrayList<>();
		this.tasks = new TreeSet<>();
	}
	
	
	public String getName() {
		return projName;
	}
	
    public void setName(String name) {
        this.projName = name;
        updateAll();
    }
	
    public void updateAll() {
        Main.DIRTY = true;
        if(!listeners.isEmpty())
            listeners.get(0).update();
    }

	public ArrayList<String> getColumns(){
		return columnNames;
	}
	
    public void attach(ModelListener listener) {
        listeners.add(listener);
    }
    
    public void removeTask(TaskModel task) {
        this.columnNames.remove(task);
        updateAll();
    }
    public void addColumn(String column) {
        this.columnNames.add(column);
        updateAll();
    }
    public void removeColumn(String column) {
        this.columnNames.remove(column);
        updateAll();
    }
    
    public void addTask(TaskModel task){
        this.tasks.add(task);
        updateAll();
    }


	public void setColumns(ArrayList<String> cl) {
		this.columnNames = cl;
		
	}


	public TreeSet<TaskModel> getTasks() {
		return tasks;
	}


	
	public void setTaskSet(TreeSet<TaskModel> temp) {
        this.tasks = temp;
        updateAll();
	}

}
