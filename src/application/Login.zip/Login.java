package application;
import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.effect.DropShadow;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontPosture;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.stage.Stage;
public class Login {
	
	private Stage login;
	private Text error = new Text("");
	private final String user = "123";
	private final String password = "123";
	private TextField userField;
	private PasswordField pwField;
	
	public Login(Stage stage) throws Exception{
		stage.setTitle("Task Board Login");
		login = stage;
		
		GridPane grid = new GridPane();
		grid.setAlignment(Pos.CENTER);
		grid.setVgap(10);
		grid.setHgap(10);
		grid.setPadding(new Insets( 30,30,30,30));
		Scene scene = new Scene(grid, 400, 400);
		stage.setScene(scene);
		
		Text sceneTitle = new Text("Welcome To Your TaskBoard");
		sceneTitle.setFont(Font.font("Veranda", FontWeight.NORMAL, 15));
		grid.add(sceneTitle, 1, 1);
		
		Label user = new Label("Username");
		user.setTextFill(Color.RED);
		grid.add(user,0, 2);
		
		userField = new TextField();
		userField.setPromptText("Enter UserName");
		grid.add(userField, 1, 2);
		
		Label password = new Label("Password");
		password.setTextFill(Color.RED);
		grid.add(password, 0, 3);
		
		pwField = new PasswordField();
		pwField.setPromptText("Enter Password");
		grid.add(pwField, 1, 3);
		grid.add(error,1,5);
		
		Button signin = new Button("Login");
		HBox hbButton = new HBox(10);
		hbButton.setAlignment(Pos.BOTTOM_RIGHT);
		hbButton.getChildren().add(signin);
		grid.add(hbButton, 1, 4);
		
		signin.setOnAction(event -> {
		  if(check(userField.getText(), pwField.getText())){
			  try {
				Main.openMainScreen();
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			  this.login.close();
		  }
		 });
	       
		login.show();
		
		
	}
	public boolean check(String username, String password){
		boolean success = false; 
		if(username.equals(user) && password.equals(password)){
			success = true;
		}
		if(success == false){
			error.setText("Incorrect user or password.");
			error.setFill(Color.RED);
		}
		userField.setText("");
		pwField.setText("");
		return success;
	}
	public static void main(String[] args) {
	      Application.launch(args);
	   }
	
}
