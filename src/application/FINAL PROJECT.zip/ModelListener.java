package application;

public interface ModelListener {
    void update();
}